# AI Resume Generator

An AI-powered resume optimizer. Users paste their career history and a job description, and the app uses Groq LLaMA to generate a tailored ATS-friendly resume, cover letter, professional summary, and skills section — downloadable as PDF or DOCX.

## Run & Operate

- `artifacts/resume-ai: web` workflow — React frontend (port 18731, served at `/`)
- `artifacts/api-server: API Server` workflow — Python FastAPI backend (port 8080, served at `/api`)
- Required secret: `GROQ_API_KEY` — Get a free key at https://console.groq.com

## Stack

- **Frontend:** React + Vite + Tailwind CSS + shadcn/ui (Plus Jakarta Sans font)
- **Backend:** Python FastAPI + Uvicorn
- **AI:** Groq API (llama-3.1-8b-instant)
- **PDF export:** ReportLab
- **DOCX export:** python-docx

## Where things live

```
artifacts/resume-ai/src/          — React frontend
artifacts/api-server/backend/     — Python FastAPI backend
  ├── main.py                      — FastAPI app + routes
  ├── ai_engine.py                 — Groq API integration
  ├── pdf_generator.py             — ReportLab PDF generation
  └── docx_generator.py           — python-docx DOCX generation
```

## Architecture decisions

- Python FastAPI replaces the default Node.js api-server, running from the same `/api` path at port 8080
- Groq `llama-3.1-8b-instant` is used for speed (sub-10s generation) over heavier models
- AI returns structured JSON (name, summary, skills, work_experience, education, cover_letter) that is then formatted by separate PDF/DOCX generators
- Stateless design — no database needed; each request is self-contained
- ReportLab used instead of WeasyPrint (pure Python, no system deps)

## User preferences

_Populate as you build._

## Gotchas

- The FastAPI backend must be run from `artifacts/api-server/` as working directory (uses relative imports for `backend.*`)
- After any Python file change, the uvicorn `--reload` flag auto-restarts the server
- The AI JSON output strips markdown fences before parsing — Groq sometimes wraps JSON in ```json blocks
