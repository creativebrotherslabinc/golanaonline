from docx import Document

def generate_docx(text):
    doc = Document()
    doc.add_paragraph(text)
    filename = "resume.docx"
    doc.save(filename)
    return filename
