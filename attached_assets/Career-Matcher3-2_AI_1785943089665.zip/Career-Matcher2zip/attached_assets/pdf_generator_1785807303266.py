from weasyprint import HTML

def generate_pdf(html_content):
    HTML(string=html_content).write_pdf("resume.pdf")
    return "resume.pdf"
