document.getElementById("resumeForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const personalInfo = document.getElementById("personalInfo").value;
    const jobDescription = document.getElementById("jobDescription").value;
    const fileType = document.getElementById("fileType").value;

    document.getElementById("status").innerText = "Generating resume...";

    const formData = new FormData();
    formData.append("personal_info", personalInfo);
    formData.append("job_description", jobDescription);
    formData.append("file_type", fileType);

    const response = await fetch("http://localhost:8000/generate", {
        method: "POST",
        body: formData
    });

    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = fileType === "pdf" ? "resume.pdf" : "resume.docx";
    a.click();

    document.getElementById("status").innerText = "Download ready!";
});
