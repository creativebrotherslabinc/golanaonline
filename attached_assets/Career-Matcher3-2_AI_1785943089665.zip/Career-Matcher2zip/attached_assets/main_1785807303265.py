from fastapi import FastAPI, Form
from fastapi.responses import FileResponse
from ai_engine import generate_resume_text
from pdf_generator import generate_pdf
from docx_generator import generate_docx

app = FastAPI()

@app.post("/generate")
def generate(
    personal_info: str = Form(...),
    job_description: str = Form(...),
    file_type: str = Form(...)
):
    prompt = f"""
    You are an expert resume writer.

    USER PERSONAL INFO:
    {personal_info}

    JOB DESCRIPTION:
    {job_description}

    TASK:
    - Rewrite the resume to match the job description.
    - Create: ATS resume, modern resume, cover letter, summary, skills section.
    - Format cleanly.
    """

    result = generate_resume_text(prompt)

    if file_type == "pdf":
        pdf_path = generate_pdf(result)
        return FileResponse(pdf_path, media_type="application/pdf", filename="resume.pdf")

    else:
        docx_path = generate_docx(result)
        return FileResponse(docx_path, media_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document", filename="resume.docx")
