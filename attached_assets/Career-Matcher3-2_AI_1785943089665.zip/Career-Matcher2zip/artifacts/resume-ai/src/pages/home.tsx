import React, { useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import {
  FileText,
  FileBadge2,
  ChevronRight,
  Sparkles,
  Download,
  AlertCircle,
  RefreshCcw,
  CheckCircle2,
  Copy,
  Zap,
  Plus,
  X,
  Cpu,
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const LOADING_MESSAGES = [
  "Analyzing your career trajectory...",
  "Extracting key achievements...",
  "Aligning experience with job requirements...",
  "Optimizing keywords for ATS systems...",
  "Formatting your professional narrative...",
  "Finalizing your tailored resumes...",
];

const MAX_TARGETS = 5;

export default function Home() {
  const [careerHistory, setCareerHistory] = useState("");
  const [jobDescriptions, setJobDescriptions] = useState<string[]>([""]);
  const [activeTarget, setActiveTarget] = useState(0);
  const [fileType, setFileType] = useState<"pdf" | "docx">("pdf");
  const [provider, setProvider] = useState<"groq" | "gemini">("groq");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");
  const [loadingMsgIndex, setLoadingMsgIndex] = useState(0);
  const [generatedCount, setGeneratedCount] = useState(0);

  const { toast } = useToast();

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (status === "loading") {
      interval = setInterval(() => {
        setLoadingMsgIndex((prev) => (prev + 1) % LOADING_MESSAGES.length);
      }, 3000);
    } else {
      setLoadingMsgIndex(0);
    }
    return () => clearInterval(interval);
  }, [status]);

  const addTarget = useCallback(() => {
    setJobDescriptions((prev) => {
      if (prev.length >= MAX_TARGETS) return prev;
      const next = [...prev, ""];
      setActiveTarget(next.length - 1);
      return next;
    });
  }, []);

  const removeTarget = useCallback((index: number) => {
    setJobDescriptions((prev) => {
      if (prev.length <= 1) return prev;
      const next = prev.filter((_, i) => i !== index);
      setActiveTarget((a) => Math.min(a, next.length - 1));
      return next;
    });
  }, []);

  const updateTarget = useCallback((value: string) => {
    setJobDescriptions((prev) => {
      const next = [...prev];
      next[activeTarget] = value;
      return next;
    });
  }, [activeTarget]);

  const handleGenerate = useCallback(async () => {
    const filledDescriptions = jobDescriptions.map((d) => d.trim()).filter(Boolean);

    if (!careerHistory.trim() || filledDescriptions.length === 0) {
      toast({
        title: "Missing information",
        description: "Please provide both your career history and at least one job description.",
        variant: "destructive",
      });
      return;
    }

    setStatus("loading");
    setErrorMessage("");

    try {
      if (filledDescriptions.length === 1) {
        // Single target — use original endpoint, download directly
        const formData = new FormData();
        formData.append("career_history", careerHistory);
        formData.append("job_description", filledDescriptions[0]);
        formData.append("file_type", fileType);
        formData.append("provider", provider);

        const response = await fetch("/api/generate", {
          method: "POST",
          body: formData,
        });

        if (!response.ok) {
          let errorText = "An unexpected error occurred.";
          try {
            const errData = await response.json();
            errorText = errData.detail || errData.message || errData.error || errorText;
          } catch {
            errorText = await response.text();
          }
          throw new Error(errorText);
        }

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `Tailored_Resume.${fileType}`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
        setGeneratedCount(1);
      } else {
        // Multiple targets — use multi endpoint, download ZIP
        const formData = new FormData();
        formData.append("career_history", careerHistory);
        formData.append("job_descriptions", JSON.stringify(filledDescriptions));
        formData.append("file_type", fileType);
        formData.append("provider", provider);

        const response = await fetch("/api/generate-multi", {
          method: "POST",
          body: formData,
        });

        if (!response.ok) {
          let errorText = "An unexpected error occurred.";
          try {
            const errData = await response.json();
            errorText = errData.detail || errData.message || errData.error || errorText;
          } catch {
            errorText = await response.text();
          }
          throw new Error(errorText);
        }

        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `Tailored_Resumes.zip`;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
        setGeneratedCount(filledDescriptions.length);
      }

      setStatus("success");
    } catch (error: any) {
      console.error(error);
      setStatus("error");
      setErrorMessage(error.message || "Failed to generate resume. Please try again.");
    }
  }, [careerHistory, jobDescriptions, fileType, toast]);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col relative overflow-hidden">
      {/* Background aesthetic blobs */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[40%] rounded-full bg-primary/5 blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[40%] rounded-full bg-blue-500/5 blur-[120px] pointer-events-none" />

      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-10 md:py-20 z-10 flex flex-col items-center">

        {/* Hero Section */}
        <section className="w-full text-center mb-10 sm:mb-16 space-y-4 sm:space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary font-medium text-sm mb-2 border border-primary/20">
            <Sparkles className="w-4 h-4 shrink-0" />
            <span>AI-Powered Precision</span>
          </div>
          <h1 className="text-3xl sm:text-4xl md:text-6xl font-extrabold tracking-tight max-w-4xl mx-auto leading-[1.1]">
            Stop rewriting your resume.{' '}
            <span className="text-primary">Start landing interviews.</span>
          </h1>
          <p className="text-muted-foreground text-base sm:text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
            Paste your raw career history and the target job description. We'll analyze the role,
            highlight your most relevant achievements, and instantly generate a perfectly tailored
            resume designed to beat ATS and impress hiring managers.
          </p>
        </section>

        {/* How it Works */}
        <section className="w-full mb-10 sm:mb-16 max-w-4xl">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6">
            <div className="flex flex-col items-center text-center space-y-3 p-5 sm:p-6 rounded-2xl bg-card border border-border shadow-sm">
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-muted flex items-center justify-center text-primary mb-1">
                <Copy className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              <h3 className="font-semibold text-base sm:text-lg">1. Paste Your Story</h3>
              <p className="text-sm text-muted-foreground">Drop in your LinkedIn profile, current resume, or raw work history notes.</p>
            </div>
            <div className="flex flex-col items-center text-center space-y-3 p-5 sm:p-6 rounded-2xl bg-card border border-border shadow-sm relative">
              <div className="hidden sm:block absolute top-1/2 -left-3 -translate-y-1/2 -translate-x-1/2 text-muted-foreground/30">
                <ChevronRight className="w-8 h-8" />
              </div>
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-1">
                <Zap className="w-5 h-5 sm:w-6 sm:h-6 text-primary fill-primary/20" />
              </div>
              <h3 className="font-semibold text-base sm:text-lg">2. Target the Role</h3>
              <p className="text-sm text-muted-foreground">Paste up to 5 job descriptions. We'll generate a tailored resume for each.</p>
              <div className="hidden sm:block absolute top-1/2 -right-3 -translate-y-1/2 translate-x-1/2 text-muted-foreground/30">
                <ChevronRight className="w-8 h-8" />
              </div>
            </div>
            <div className="flex flex-col items-center text-center space-y-3 p-5 sm:p-6 rounded-2xl bg-card border border-border shadow-sm">
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-muted flex items-center justify-center text-primary mb-1">
                <Download className="w-5 h-5 sm:w-6 sm:h-6" />
              </div>
              <h3 className="font-semibold text-base sm:text-lg">3. Get Tailored PDF</h3>
              <p className="text-sm text-muted-foreground">Instantly download a professionally formatted, highly-targeted resume.</p>
            </div>
          </div>
        </section>

        {/* Interactive App Area */}
        <section className="w-full max-w-5xl relative">
          <AnimatePresence mode="wait">
            {status === "idle" && (
              <motion.div
                key="form"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
              >
                <Card className="shadow-xl shadow-primary/5 border-border overflow-hidden">
                  <div className="h-1.5 bg-gradient-to-r from-primary/80 to-blue-400" />
                  <CardContent className="p-4 sm:p-6 md:p-8 space-y-6 sm:space-y-8">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-8">
                      {/* Career History */}
                      <div className="space-y-2 sm:space-y-3">
                        <Label htmlFor="careerHistory" className="text-sm sm:text-base font-semibold flex items-center gap-2">
                          <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs shrink-0">1</div>
                          Your Career History
                        </Label>
                        <Textarea
                          id="careerHistory"
                          data-testid="input-career-history"
                          placeholder={"Paste your current resume, LinkedIn summary, or just write down what you've done.\n\nE.g.\n- Software Engineer at Acme Corp (2020-2023)\n- Built a scalable microservices architecture...\n- Managed a team of 3 developers..."}
                          className="min-h-[180px] sm:min-h-[260px] md:min-h-[300px] resize-y bg-muted/30 focus:bg-background transition-colors text-sm sm:text-base p-3 sm:p-4 leading-relaxed"
                          value={careerHistory}
                          onChange={(e) => setCareerHistory(e.target.value)}
                        />
                      </div>

                      {/* Job Description — with target tabs */}
                      <div className="space-y-2 sm:space-y-3">
                        <Label className="text-sm sm:text-base font-semibold flex items-center gap-2">
                          <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs shrink-0">2</div>
                          Target Job Description
                        </Label>

                        {/* Target tabs */}
                        <div className="flex items-center gap-1.5 flex-wrap">
                          {jobDescriptions.map((desc, i) => (
                            <button
                              key={i}
                              type="button"
                              onClick={() => setActiveTarget(i)}
                              className={[
                                "group relative inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-semibold border transition-all",
                                activeTarget === i
                                  ? "bg-primary text-primary-foreground border-primary shadow-sm"
                                  : desc.trim()
                                  ? "bg-primary/10 text-primary border-primary/30 hover:bg-primary/20"
                                  : "bg-muted text-muted-foreground border-border hover:bg-muted/80",
                              ].join(" ")}
                            >
                              Target {i + 1}
                              {jobDescriptions.length > 1 && (
                                <span
                                  role="button"
                                  tabIndex={0}
                                  aria-label={`Remove target ${i + 1}`}
                                  onClick={(e) => { e.stopPropagation(); removeTarget(i); }}
                                  onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.stopPropagation(); removeTarget(i); } }}
                                  className={[
                                    "ml-0.5 rounded-full w-3.5 h-3.5 flex items-center justify-center transition-opacity",
                                    activeTarget === i
                                      ? "opacity-70 hover:opacity-100"
                                      : "opacity-0 group-hover:opacity-60 hover:!opacity-100",
                                  ].join(" ")}
                                >
                                  <X className="w-2.5 h-2.5" />
                                </span>
                              )}
                            </button>
                          ))}
                          {jobDescriptions.length < MAX_TARGETS && (
                            <button
                              type="button"
                              onClick={addTarget}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium border border-dashed border-border text-muted-foreground hover:border-primary/50 hover:text-primary transition-all"
                            >
                              <Plus className="w-3 h-3" />
                              Add target
                            </button>
                          )}
                        </div>

                        <Textarea
                          id="jobDescription"
                          data-testid="input-job-description"
                          placeholder={"Paste the full job description here. We will analyze the required skills and tone to tailor your experience perfectly.\n\nE.g.\nSeeking a Senior Frontend Engineer with React experience. Must have 5+ years building SaaS products..."}
                          className="min-h-[180px] sm:min-h-[260px] md:min-h-[300px] resize-y bg-muted/30 focus:bg-background transition-colors text-sm sm:text-base p-3 sm:p-4 leading-relaxed"
                          value={jobDescriptions[activeTarget]}
                          onChange={(e) => updateTarget(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="pt-4 sm:pt-6 border-t border-border flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 sm:gap-6">
                      <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 w-full sm:w-auto">
                        {/* Output Format */}
                        <div className="space-y-2">
                          <Label className="text-xs sm:text-sm text-muted-foreground font-medium">Output Format</Label>
                          <ToggleGroup
                            type="single"
                            value={fileType}
                            onValueChange={(val) => val && setFileType(val as "pdf" | "docx")}
                            className="justify-start border border-border rounded-lg p-1 bg-muted/20 w-full sm:w-auto"
                          >
                            <ToggleGroupItem value="pdf" aria-label="Toggle PDF" data-testid="toggle-pdf" className="flex-1 sm:flex-none px-4 sm:px-5 data-[state=on]:bg-card data-[state=on]:shadow-sm">
                              <FileText className="w-4 h-4 mr-2" /> PDF
                            </ToggleGroupItem>
                            <ToggleGroupItem value="docx" aria-label="Toggle DOCX" data-testid="toggle-docx" className="flex-1 sm:flex-none px-4 sm:px-5 data-[state=on]:bg-card data-[state=on]:shadow-sm">
                              <FileBadge2 className="w-4 h-4 mr-2" /> DOCX
                            </ToggleGroupItem>
                          </ToggleGroup>
                        </div>

                        {/* AI Engine */}
                        <div className="space-y-2">
                          <Label className="text-xs sm:text-sm text-muted-foreground font-medium flex items-center gap-1.5">
                            <Cpu className="w-3.5 h-3.5" /> AI Engine
                          </Label>
                          <ToggleGroup
                            type="single"
                            value={provider}
                            onValueChange={(val) => val && setProvider(val as "groq" | "gemini")}
                            className="justify-start border border-border rounded-lg p-1 bg-muted/20 w-full sm:w-auto"
                          >
                            <ToggleGroupItem value="groq" aria-label="Use Groq" className="flex-1 sm:flex-none px-4 sm:px-5 data-[state=on]:bg-card data-[state=on]:shadow-sm gap-2">
                              <span className="text-xs font-bold tracking-tight">⚡ Groq</span>
                              <span className="hidden sm:inline text-xs text-muted-foreground">Llama 3.3 70B</span>
                            </ToggleGroupItem>
                            <ToggleGroupItem value="gemini" aria-label="Use Gemini" className="flex-1 sm:flex-none px-4 sm:px-5 data-[state=on]:bg-card data-[state=on]:shadow-sm gap-2">
                              <span className="text-xs font-bold tracking-tight">✦ Gemini</span>
                              <span className="hidden sm:inline text-xs text-muted-foreground">2.0 Flash</span>
                            </ToggleGroupItem>
                          </ToggleGroup>
                        </div>
                      </div>

                      <Button
                        size="lg"
                        data-testid="button-generate"
                        className="w-full sm:w-auto text-base sm:text-lg h-12 sm:h-14 px-6 sm:px-10 shadow-lg shadow-primary/20 hover:shadow-primary/40 transition-all font-bold group"
                        onClick={handleGenerate}
                      >
                        <Sparkles className="w-5 h-5 mr-2 group-hover:animate-pulse shrink-0" />
                        {jobDescriptions.filter((d) => d.trim()).length > 1
                          ? `Generate ${jobDescriptions.filter((d) => d.trim()).length} Resumes`
                          : "Generate My Resume"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {status === "loading" && (
              <motion.div
                key="loading"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.05 }}
                className="w-full flex justify-center py-10 sm:py-20"
              >
                <Card className="w-full max-w-xl shadow-2xl shadow-primary/10 border-primary/20 bg-card overflow-hidden">
                  <div className="h-1 w-full bg-muted overflow-hidden relative">
                    <motion.div
                      className="absolute top-0 bottom-0 bg-primary"
                      initial={{ width: "0%" }}
                      animate={{ width: "100%" }}
                      transition={{ duration: 30, ease: "linear" }}
                    />
                  </div>
                  <CardContent className="p-6 sm:p-10 md:p-12 flex flex-col items-center text-center space-y-6 sm:space-y-8">
                    <div className="relative">
                      <div className="absolute inset-0 rounded-full bg-primary/20 animate-ping" />
                      <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-primary/10 flex items-center justify-center relative z-10 border border-primary/20">
                        <Sparkles className="w-8 h-8 sm:w-10 sm:h-10 text-primary animate-pulse" />
                      </div>
                    </div>
                    <div className="space-y-3 min-h-[5rem] flex flex-col justify-center">
                      <h3 className="text-xl sm:text-2xl font-bold tracking-tight">Crafting your application</h3>
                      <AnimatePresence mode="wait">
                        <motion.p
                          key={loadingMsgIndex}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          className="text-muted-foreground font-medium text-sm sm:text-base"
                        >
                          {LOADING_MESSAGES[loadingMsgIndex]}
                        </motion.p>
                      </AnimatePresence>
                    </div>
                    <p className="text-xs text-muted-foreground/60">
                      This usually takes 15–30 seconds. Do not close this page.
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {status === "success" && (
              <motion.div
                key="success"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full flex justify-center py-6 sm:py-10"
              >
                <Card className="w-full max-w-2xl shadow-xl shadow-green-500/5 border-green-500/20 bg-card">
                  <CardContent className="p-6 sm:p-10 md:p-12 flex flex-col items-center text-center space-y-4 sm:space-y-6">
                    <div className="w-16 h-16 sm:w-24 sm:h-24 rounded-full bg-green-500/10 flex items-center justify-center border border-green-500/20">
                      <CheckCircle2 className="w-8 h-8 sm:w-12 sm:h-12 text-green-500" />
                    </div>
                    <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">
                      {generatedCount > 1 ? `${generatedCount} Resumes Ready` : "Your Resume is Ready"}
                    </h2>
                    <p className="text-base sm:text-lg text-muted-foreground max-w-md">
                      {generatedCount > 1
                        ? `${generatedCount} tailored ${fileType.toUpperCase()} files have been downloaded as a ZIP archive.`
                        : `We've tailored your career history to match the job description. Your ${fileType.toUpperCase()} file has been downloaded.`}
                    </p>

                    <div className="pt-4 sm:pt-8 flex flex-col sm:flex-row gap-3 sm:gap-4 w-full justify-center">
                      <Button
                        variant="outline"
                        size="lg"
                        data-testid="button-create-another"
                        className="font-semibold border-border w-full sm:w-auto"
                        onClick={() => setStatus("idle")}
                      >
                        <RefreshCcw className="w-4 h-4 mr-2" />
                        Create Another
                      </Button>
                      <Button
                        size="lg"
                        data-testid="button-regenerate"
                        className="font-semibold shadow-md w-full sm:w-auto"
                        onClick={handleGenerate}
                      >
                        <Zap className="w-4 h-4 mr-2" />
                        Regenerate Same Options
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}

            {status === "error" && (
              <motion.div
                key="error"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="w-full flex justify-center py-6 sm:py-10"
              >
                <Card className="w-full max-w-2xl shadow-xl shadow-destructive/5 border-destructive/20 bg-card">
                  <CardContent className="p-6 sm:p-10 md:p-12 flex flex-col items-center text-center space-y-4 sm:space-y-6">
                    <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-destructive/10 flex items-center justify-center border border-destructive/20">
                      <AlertCircle className="w-8 h-8 sm:w-10 sm:h-10 text-destructive" />
                    </div>
                    <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">Generation Failed</h2>
                    <div className="p-3 sm:p-4 rounded-xl bg-destructive/5 border border-destructive/10 text-destructive-foreground text-sm max-w-md break-words w-full">
                      {errorMessage}
                    </div>
                    <div className="pt-2 sm:pt-6">
                      <Button
                        size="lg"
                        variant="default"
                        data-testid="button-error-retry"
                        className="font-semibold w-full sm:w-auto"
                        onClick={() => setStatus("idle")}
                      >
                        <RefreshCcw className="w-4 h-4 mr-2" />
                        Go Back and Try Again
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </section>

      </main>

      <footer className="w-full py-6 sm:py-8 text-center text-muted-foreground border-t border-border mt-auto z-10 relative bg-card/50">
        <div className="flex items-center justify-center gap-2 mb-1 font-semibold text-foreground text-sm sm:text-base">
          <Sparkles className="w-4 h-4 text-primary" />
          <span>ResumeAI Professional</span>
        </div>
        <p className="text-xs sm:text-sm">The precision of a career coach. The speed of AI.</p>
      </footer>
    </div>
  );
}
