import io
import os
import json
import zipfile
import logging
import traceback
from fastapi import FastAPI, Form, HTTPException
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
from backend.ai_engine import generate_resume_content
from backend.pdf_generator import generate_pdf
from backend.docx_generator import generate_docx

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="AI Resume Generator API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _check_provider(provider: str):
    if provider == "gemini" and not os.environ.get("GEMINI_API_KEY"):
        raise HTTPException(
            status_code=503,
            detail="Gemini API key not configured. Please add your GEMINI_API_KEY.",
        )
    if provider != "gemini" and not os.environ.get("GROQ_API_KEY"):
        raise HTTPException(
            status_code=503,
            detail="AI service not configured. Please add your GROQ_API_KEY.",
        )


def _build_file(resume_content: dict, file_type: str) -> tuple[bytes, str, str]:
    if file_type == "pdf":
        return generate_pdf(resume_content), "application/pdf", "pdf"
    else:
        mime = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        return generate_docx(resume_content), mime, "docx"


@app.get("/api/healthz")
def healthz():
    return {"status": "ok"}


@app.post("/api/generate")
async def generate(
    career_history: str = Form(...),
    job_description: str = Form(...),
    file_type: str = Form(default="pdf"),
    provider: str = Form(default="groq"),
):
    if not career_history.strip() or not job_description.strip():
        raise HTTPException(
            status_code=400,
            detail="Both career history and job description are required",
        )
    _check_provider(provider)

    try:
        resume_content = generate_resume_content(career_history, job_description, provider)
    except Exception as e:
        logger.error("AI generation failed:\n%s", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"AI generation failed: {str(e)}")

    try:
        file_bytes, media_type, ext = _build_file(resume_content, file_type)
        return StreamingResponse(
            io.BytesIO(file_bytes),
            media_type=media_type,
            headers={"Content-Disposition": f"attachment; filename=resume.{ext}"},
        )
    except Exception as e:
        logger.error("Document generation failed:\n%s", traceback.format_exc())
        raise HTTPException(status_code=500, detail=f"Document generation failed: {str(e)}")


@app.post("/api/generate-multi")
async def generate_multi(
    career_history: str = Form(...),
    job_descriptions: str = Form(...),  # JSON array of strings
    file_type: str = Form(default="pdf"),
    provider: str = Form(default="groq"),
):
    if not career_history.strip():
        raise HTTPException(status_code=400, detail="Career history is required")
    _check_provider(provider)

    try:
        descriptions = json.loads(job_descriptions)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid job_descriptions format")

    descriptions = [d.strip() for d in descriptions if d.strip()]
    if not descriptions:
        raise HTTPException(status_code=400, detail="At least one job description is required")
    if len(descriptions) > 5:
        raise HTTPException(status_code=400, detail="Maximum 5 job descriptions allowed")

    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
        for idx, job_desc in enumerate(descriptions, start=1):
            try:
                resume_content = generate_resume_content(career_history, job_desc, provider)
            except Exception as e:
                logger.error("AI generation failed for target %d:\n%s", idx, traceback.format_exc())
                raise HTTPException(
                    status_code=500,
                    detail=f"AI generation failed for target {idx}: {str(e)}",
                )
            try:
                file_bytes, _, ext = _build_file(resume_content, file_type)
                zf.writestr(f"Resume_Target_{idx}.{ext}", file_bytes)
            except Exception as e:
                logger.error("Document generation failed for target %d:\n%s", idx, traceback.format_exc())
                raise HTTPException(
                    status_code=500,
                    detail=f"Document generation failed for target {idx}: {str(e)}",
                )

    zip_buffer.seek(0)
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=Tailored_Resumes.zip"},
    )
