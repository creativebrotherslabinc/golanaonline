# FindingMyFood

A restaurant roulette web app that helps users randomly choose a restaurant matching their preferences. Users pick cuisine, price range, dining style, and group size — then spin a roulette wheel to land on their next meal.

## Run & Operate

- `pnpm --filter @workspace/finding-my-food run dev` — run the main website (port 18661, preview at `/`)
- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080, preview at `/api`)

## Stack

- Pure HTML, CSS, Vanilla JavaScript (no frameworks)
- Vite dev server (serving static files)
- OpenStreetMap Overpass API for restaurant data (no API key required)
- Nominatim for geocoding / reverse geocoding (no API key required)
- Google Maps URL scheme for directions (no API key required)

## Where things live

- `artifacts/finding-my-food/index.html` — main HTML (both pages: search + roulette)
- `artifacts/finding-my-food/style.css` — all styling
- `artifacts/finding-my-food/script.js` — all logic (geolocation, API, wheel, animation)

## Architecture decisions

- No framework: pure HTML/CSS/JS as requested; Vite is only a dev server
- Overpass API (OpenStreetMap) replaces Google Places — free, no API key needed
- Roulette wheel drawn on `<canvas>` once; CSS `transform: rotate()` + transition handles animation
- Winner angle calculated before spin so wheel lands exactly on chosen restaurant
- Nominatim geocoding for manual city/postal code entry and reverse geocoding of GPS coordinates

## User preferences

- Keep project simple and minimal
- No React, Vue, Angular or other frameworks
- One CSS file, one JS file
- No over-engineering or unrequested features
