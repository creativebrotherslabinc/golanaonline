import { Router, type IRouter, type Request, type Response } from "express";

const router: IRouter = Router();

const USER_AGENT = "FindingMyFood/1.0 (restaurant roulette app; contact via replit)";

// ── POST /api/overpass ─────────────────────────────────────────────────────
// Body: { query: string }
// Proxies to Overpass API — avoids browser CORS / egress restrictions.
router.post("/overpass", async (req: Request, res: Response) => {
  const { query } = req.body as { query?: string };
  if (!query) {
    res.status(400).json({ error: "Missing query" });
    return;
  }

  try {
    const response = await fetch("https://overpass-api.de/api/interpreter", {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": USER_AGENT,
      },
      body: `data=${encodeURIComponent(query)}`,
      signal: AbortSignal.timeout(35_000),
    });

    if (!response.ok) {
      res.status(502).json({ error: `Overpass returned ${response.status}` });
      return;
    }

    const data = await response.json();
    res.json(data);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    res.status(502).json({ error: `Overpass proxy failed: ${msg}` });
  }
});

// ── GET /api/geocode/search?q=... ──────────────────────────────────────────
// Proxies Nominatim forward geocoding (text → coordinates).
router.get("/geocode/search", async (req: Request, res: Response) => {
  const q = req.query.q as string | undefined;
  if (!q) {
    res.status(400).json({ error: "Missing q parameter" });
    return;
  }

  try {
    const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q)}&format=json&limit=1`;
    const response = await fetch(url, {
      headers: {
        "User-Agent": USER_AGENT,
        "Accept-Language": "en",
      },
      signal: AbortSignal.timeout(10_000),
    });

    if (!response.ok) {
      res.status(502).json({ error: `Nominatim returned ${response.status}` });
      return;
    }

    const data = await response.json();
    res.json(data);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    res.status(502).json({ error: `Geocode proxy failed: ${msg}` });
  }
});

// ── GET /api/geocode/reverse?lat=...&lon=... ───────────────────────────────
// Proxies Nominatim reverse geocoding (coordinates → place name).
router.get("/geocode/reverse", async (req: Request, res: Response) => {
  const { lat, lon } = req.query as { lat?: string; lon?: string };
  if (!lat || !lon) {
    res.status(400).json({ error: "Missing lat or lon" });
    return;
  }

  try {
    const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=json`;
    const response = await fetch(url, {
      headers: {
        "User-Agent": USER_AGENT,
        "Accept-Language": "en",
      },
      signal: AbortSignal.timeout(10_000),
    });

    if (!response.ok) {
      res.status(502).json({ error: `Nominatim returned ${response.status}` });
      return;
    }

    const data = await response.json();
    res.json(data);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : "Unknown error";
    res.status(502).json({ error: `Reverse geocode proxy failed: ${msg}` });
  }
});

export default router;
